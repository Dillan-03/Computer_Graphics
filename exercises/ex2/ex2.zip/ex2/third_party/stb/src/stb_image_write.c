#define STB_IMAGE_WRITE_IMPLEMENTATION 1
#include <stb_image_write.h>
