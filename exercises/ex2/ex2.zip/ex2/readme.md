COMP3811 Exercise G.2
=====================

Code for Exercise G.2 in COMP3811. Do not re-distribute the code outside of
Minerva.


